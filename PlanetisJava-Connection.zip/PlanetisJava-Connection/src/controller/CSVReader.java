/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import model.IReader;

/**
 *
 * @author Koen
 */
public class CSVReader implements IReader {

    /**
     *
     * @param csvFolderPath
     */
    @Override
    public ArrayList readFile(String csvFolderPath, String fileName) {
        return null;



    }

    /**
     *
     * @param csvFolderPath
     * @return
     * @throws UnsupportedEncodingException
     * @throws FileNotFoundException
     */
    
}
